'use strict'


const express = require('express')
const employerRouter = express.Router()

const employerController = require('../controller/employerController')


employerRouter.route('/api/employer')
.get((req, res) => employerController.getEmployer(req, res))
.post((req, res) => employerController.createEmployer(req, res))
.put((req, res) => employerController.updateEmployer(req, res))


employerRouter.route('/api/employer/:id')
.get((req, res) => employerController.getEmployer(req, res))
.delete((req, res) => employerController.deleteEmployerById(req, res))



module.exports = employerRouter
