const order = require('../models/Order');
const jwtService = require('jsonwebtoken');

module.exports = {
    getOrders: (req, res) => {
        order.find({}).select(["-__v", "-_id"]).then((result) => {
            res.status(200).json(result);
        }).catch(() => {
            res.status(500).json({ message: "Não foi possível recuperar os pedidos" });
        });
    },
    deleteOrderById: async (req, res) => {
        try {
            const result = await order.deleteOne({ codPedido: req.params.id });
            if (result.deletedCount > 0) {
                res.status(200).json({ message: "Pedido removido com sucesso" });
            } else {
                res.status(404).json({ message: "Pedido não encontrado para remoção" });
            }
        } catch (err) {
            res.status(500).json({ message: "Não foi possível remover o pedido" });
        }
    },
    getOrder: async (req, res) => {
        try {
            const result = await order.findOne({ codPedido: req.body.codPedido });
            if (!result) {
                res.status(404).json({ message: "Pedido não encontrado" });
            } else {
                res.status(200).json(result);
            }
        } catch (err) {
            res.status(500).json({ message: "Não foi possível recuperar o pedido no momento" });
        }
    },
    updateOrder: async (req, res) => {
        try {
            const result = await order.updateOne({ codPedido: req.body.codPedido }, req.body);
            if (result.nModified > 0) {
                res.status(200).json({ message: "Pedido atualizado com sucesso" });
            } else {
                res.status(404).json({ message: "Pedido não encontrado para atualização" });
            }
        } catch (err) {
            res.status(500).json({ message: "Não foi possível atualizar os dados" });
        }
    },
    createOrder: async (req, res) => {
        try {
            const result = await order.create(req.body);
            res.status(201).json({ message: `O pedido ${result._doc.name} foi criado com sucesso` });
        } catch (err) {
            res.status(500).json({ message: `Não foi possível criar o pedido ${req.body.name}` });
        }
    },
};
