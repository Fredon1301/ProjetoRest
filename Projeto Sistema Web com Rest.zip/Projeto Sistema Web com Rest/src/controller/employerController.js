const employer = require('../models/employer');
const jwtService = require('jsonwebtoken');

module.exports = {
    getEmployers: (req, res) => {
        employer.find({}).select(["-__v", "-_id"]).then((result) => {
            res.status(200).json(result);
        }).catch(() => {
            res.status(500).json({ message: "Não foi possível recuperar os funcionários" });
        });
    },
    deleteEmployerById: async (req, res) => {
        try {
            const result = await employer.deleteOne({ cpf: req.params.id });
            if (result.deletedCount > 0) {
                res.status(200).json({ message: "Funcionário removido com sucesso" });
            } else {
                res.status(404).json({ message: "Funcionário não encontrado para remoção" });
            }
        } catch (err) {
            res.status(500).json({ message: "Não foi possível remover o funcionário" });
        }
    },
    getEmployer: async (req, res) => {
        try {
            const result = await employer.findOne({ cpf: req.body.cpf });
            if (!result) {
                res.status(404).json({ message: "Funcionário não encontrado" });
            } else {
                res.status(200).json(result);
            }
        } catch (err) {
            res.status(500).json({ message: "Não foi possível recuperar o funcionário no momento" });
        }
    },
    updateEmployer: async (req, res) => {
        try {
            const result = await employer.updateOne({ cpf: req.body.cpf }, req.body);
            if (result.nModified > 0) {
                res.status(200).json({ message: "Funcionário atualizado com sucesso" });
            } else {
                res.status(404).json({ message: "Funcionário não encontrado para atualização" });
            }
        } catch (err) {
            res.status(500).json({ message: "Não foi possível atualizar os dados" });
        }
    },
    createEmployer: async (req, res) => {
        try {
            const result = await employer.create(req.body);
            res.status(201).json({ message: `O funcionário ${result._doc.name} foi criado com sucesso` });
        } catch (err) {
            res.status(500).json({ message: `Não foi possível criar o funcionário ${req.body.name}` });
        }
    },
};
