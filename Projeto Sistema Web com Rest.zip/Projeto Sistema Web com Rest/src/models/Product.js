const mongoose = require('mongoose')

const Schema = mongoose.Schema


const userSchema = new Schema({

    name: {type: String, required: true},
    produtoDesc: {type: String, required: true},
    tipoProduto: {type: String, required: true},
    precoAtual: {type: Number, required: false},
    precoPromocao: {type: Number, required: false},
    dataValidade: {type: String, required: true},
    codProduto: {type: String, unique: true}


    

})

module.exports = mongoose.model("Product", userSchema)