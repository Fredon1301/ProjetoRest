const mongoose = require('mongoose')

const Schema = mongoose.Schema


const userSchema = new Schema({

    nameProduct: {type: String, required: true},
    precoCompra: {type: Number, required: true},
    dataCompra: {type: Date},
    codPedido: {type: String, unique: true}


    

    

})

module.exports = mongoose.model("Order", userSchema)