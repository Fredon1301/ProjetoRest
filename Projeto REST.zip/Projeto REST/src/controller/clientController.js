
const Order = require('../models/Order')
const jwtService = require('jsonwebtoken')
module.exports= {
    getOrders: (req, res) => {
       
        Order.find({}).select(["-__v", "-_id"]).then((result) => {

            res.status(200).json(result)
        }).catch(() => {


            res.status(500).json({message: "Não foi possível recuperar os clientes"})
        })
    },
    deleteOrderById: async (req, res) => {

        try {
            const result = await Order.deleteOne({cpf: req.params.id})
            res.status(200).send({message: "cliente removido com sucesso!"})
        } catch (err) {
            res.status(500).json({message: "Não foi possível remover o cliente"})
        }
    },
    getOrder: async (req, res) => {

        try {
            const result = await Order.findOne({cpf: req.body.cpf})
            res.status(200).send(result)
        } catch (err) {

            res.status(500).json({message: "Não foi possível recuperar o cliente no momento"})
        }
    },
    updateOrder: async (req, res) => {

        try {
            const result = await Order.updateOne({cpf: req.body.cpf}, req.body)
            res.status(200).send({message: "cliente atualizado com sucesso!"})
        } catch (err) {
            res.status(500).json({message: "Não foi possível atualizar os dados"})
        }
    },

    createOrder: async (req, res) => {

        try {

            const result = await Order.create(req.body)

            res.status(201).json({message: `O cliente ${result._doc.name} foi criado com sucesso!`})
        } catch (err) {


            res.status(500).json({message: `Não foi possível criar o cliente ${req.body.name}`})

        }
    },


}

