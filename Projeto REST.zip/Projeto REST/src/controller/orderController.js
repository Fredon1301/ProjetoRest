
const order = require('../models/Order')
const jwtService = require('jsonwebtoken')
module.exports= {
    getOrders: (req, res) => {
       
        order.find({}).select(["-__v", "-_id"]).then((result) => {

            res.status(200).json(result)
        }).catch(() => {


            res.status(500).json({message: "Não foi possível recuperar os Orders"})
        })
    },
    deleteOrderById: async (req, res) => {

        try {
            const result = await order.deleteOne({cpf: req.params.id})
            res.status(200).send({message: "pedido removido com sucesso!"})
        } catch (err) {
            res.status(500).json({message: "Não foi possível remover o pedido"})
        }
    },
    getOrder: async (req, res) => {

        try {
            const result = await order.findOne({cpf: req.body.cpf})
            res.status(200).send(result)
        } catch (err) {

            res.status(500).json({message: "Não foi possível recuperar o pedido no momento"})
        }
    },
    updateOrder: async (req, res) => {

        try {
            const result = await order.updateOne({cpf: req.body.cpf}, req.body)
            res.status(200).send({message: "pedido atualizado com sucesso!"})
        } catch (err) {
            res.status(500).json({message: "Não foi possível atualizar os dados"})
        }
    },

    createOrder: async (req, res) => {

        try {

            const result = await order.create(req.body)

            res.status(201).json({message: `O pedido ${result._doc.name} foi criado com sucesso!`})
        } catch (err) {


            res.status(500).json({message: `Não foi possível criar o pedido ${req.body.name}`})

        }
    },


}

