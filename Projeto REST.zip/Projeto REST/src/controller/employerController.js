
const employer = require('../models/employer')
const jwtService = require('jsonwebtoken')
module.exports= {
    getEmployers: (req, res) => {
       
        employer.find({}).select(["-__v", "-_id"]).then((result) => {

            res.status(200).json(result)
        }).catch(() => {


            res.status(500).json({message: "Não foi possível recuperar os Employers"})
        })
    },
    deleteEmployerById: async (req, res) => {

        try {
            const result = await employer.deleteOne({cpf: req.params.id})
            res.status(200).send({message: "funcionario removido com sucesso!"})
        } catch (err) {
            res.status(500).json({message: "Não foi possível remover o funcionario"})
        }
    },
    getEmployer: async (req, res) => {

        try {
            const result = await employer.findOne({cpf: req.body.cpf})
            res.status(200).send(result)
        } catch (err) {

            res.status(500).json({message: "Não foi possível recuperar o funcionario no momento"})
        }
    },
    updateEmployer: async (req, res) => {

        try {
            const result = await employer.updateOne({cpf: req.body.cpf}, req.body)
            res.status(200).send({message: "funcionario atualizado com sucesso!"})
        } catch (err) {
            res.status(500).json({message: "Não foi possível atualizar os dados"})
        }
    },

    createEmployer: async (req, res) => {

        try {

            const result = await employer.create(req.body)

            res.status(201).json({message: `O funcionario ${result._doc.name} foi criado com sucesso!`})
        } catch (err) {


            res.status(500).json({message: `Não foi possível criar o funcionario ${req.body.name}`})

        }
    },


}

